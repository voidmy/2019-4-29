var mongoose=require('mongoose');
var userSchema=require('../sch/Goodsinfo');
module.exports=mongoose.model('goodsinfo',userSchema);