var mongoose=require('mongoose');
var userSchema=require('../sch/Responseevaluation');
module.exports=mongoose.model('Responseevaluation',userSchema);