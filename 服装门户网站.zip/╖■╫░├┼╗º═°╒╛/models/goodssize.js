var mongoose=require('mongoose');
var userSchema=require('../sch/goodssize');
module.exports=mongoose.model('goodssize',userSchema);