var mongoose=require('mongoose');
var Schema=require('../sch/people');
module.exports=mongoose.model('People',Schema);