$(function () {
    //如果是管理员就显示
    var search = location.search;         //获取URL中?后的句子
    var myparval = search.split("=")[1]; //分割取出id
    if ($.cookie('level') == 3) {
        //
        var adda = $('')
        $("#setgoodsa").append('<a href="/goodsinfo/send?' + search + '" target="_blank">设置商品信息</a>')
        console.log($.cookie('level'))
    }




    $("#BuyGoods").attr('name', myparval)
    $("#BuyGoods").click(function () {//点击购买
        var src = $('#BuyGoods').attr('name')
        window.open("http://10.240.238.227:8080/public/html/payBuy.html?id=" + src + "");
    })
    //var myparval = string.replace(/public/, "..")
    $("#shwopic >img").attr('src', myparval)
    $.ajax({///得到这个商品的所有信息；
        url: '/admin/getimg',
        type: "post",
        data: { 'imgurl': search },

        success: function (result) {
            $("#goodsOne").text(result[0].GoodsDescribleOne)
            $("#goodspric").text("￥" + result[0].Price)
            var threFoure = result[0].GoodsDescribleTwo + '  ' + result[0].GoodsDescribleThree
            $("#goodtwo").text(threFoure)
            $("#goods2").text(result[0].GoodsDescribleFive)//商品描叙
        },
        error: function (err) {
            console.log(err);
        }
    });
    var allsize;
    $.ajax({ ///得到商品尺码表 
        type: 'post',
        url: '/goodsinfo/getgoodssize',
        data: { 'PicuUrl': myparval },
        dataType: 'json',
        success: function (result) {
            // console.log(result) 60  50
            // $("#secSize")
            allsize = result
            //addSizediv( $("#secSize"),result)
        }

    })
    ///
    function addSizediv(obj, sizearray) {
        // obj.append('<div calss="Addsizediv">dddd</div>')
        if (sizearray.onesize != undefined && (sizearray.onesize != 'null')) {
            obj.append('<div class="Addsizediv">' + sizearray.onesize + '</div>')
        }
        if (sizearray.twosize != undefined && (sizearray.twosize != 'null')) {
            obj.append('<div class="Addsizediv">' + sizearray.twosize + '</div>')
        }
        if (sizearray.threesize != undefined && (sizearray.threesize != 'null')) {
            obj.append('<div class="Addsizediv">' + sizearray.threesize + '</div>')
        }
        if (sizearray.foursize != undefined && (sizearray.foursize != 'null')) {
            obj.append('<div class="Addsizediv">' + sizearray.foursize + '</div>')
        }
        if (sizearray.fivesize != undefined && (sizearray.fivesize != 'null')) {

            obj.append('<div class="Addsizediv">' + sizearray.fivesize + '</div>')
        }
        if (sizearray.sixsize != undefined && (sizearray.sixsize != 'null')) {
            obj.append('<div class="Addsizediv">' + sizearray.sixsize + '</div>')
        }


    }
    var tarsize = "null"
    var newkey = 0;
    $("#secSize").delegate('div', 'click', function () {
        //alert($(this).text())
        tarsize = $(this)
        $("#secSize").children().remove()
        $("#secSize").append(tarsize)
    })
    ////
    $("#secSize").click(function () {

        if ($("#secSize").height() == 120) {
            $("#secSize").animate({ 'height': '60px' })
        }
        else {
            $("#secSize").children().remove()
            addSizediv($("#secSize"), allsize)
            $("#secSize").animate({ 'height': '120px' })
        }
    })

    $($(".errchange")[0]).css("opacity", "1")//商品描叙 op 1
    $(".errchange").mouseover(function () {
        $(this).addClass("addclasstd")
    })
    $(".errchange").mouseleave(function () {
        $(this).removeClass("addclasstd")
    })
    $(".errchange").click(function () {
        $(this).siblings().css("opacity", "0.5")
        $(this).css("opacity", "1")
        var Myname = $(this).attr("name")

        //alert(Myname)
        $('div[name=' + Myname + ']').show()///切换显示商品描叙 和评论
        if (newkey == 0) {
            tanchu(myparval)//这个设计不好 点击评论页面时 加载评论分数
            newkey++;
        }

        $('div[name=' + Myname + ']').siblings().hide()
        // console.log( $('div[name='+Myname+']').siblings())
    })
})
function tanchu(myparval) {//这个设计不好 点击评论页面时 加载评论分数

    $.ajax({//得到所有评论
        type: 'post',
        url: '/goodsinfo/getevalgoods',
        data: {
            'evalId': '22',
        },
        dataType: 'json',
        success: function (result) {
            var Lstart = new Array()
            for (var i = 0; i < result.length; i++) {

                if (result[i].PicuUrl == myparval) {

                    Lstart.push(result[i].evalstarnum)
                }

            }
            LaddAllstart(Lstart)//得到结果计算
        }
    })
    // $('#evalcalculate').text(2222)
}
function LaddAllstart(Lstart) {//得到结果计算

    var Llen = Lstart.length
    var fivestart=0//五颗星人数 就是推荐商品
    var Leverstart=new Array(5).fill(0)
    // console.log(Leverstart)
    var Lallstarnum = 0;
    $.each(Lstart, function (i, val) {
        if(val==5){
            fivestart++
            Leverstart[4]++;
        }
        else if(val==4){
            Leverstart[3]++;
        }
        else if(val==3){
            Leverstart[2]++;
        }
        else if(val==2){
            Leverstart[1]++;
        }
        else if(val==1){
            Leverstart[0]++;
        }
        Lallstarnum += Number(val)
    })
    var evastart = (Lallstarnum / Llen).toFixed(1);
    if (Llen == 0) {
        $($('.alleavlinfor')[2]).text('' + Llen + '个评价')
    }
    else {
        $($('.alleavlinfor')[0]).text(evastart)//2.5评分
        var starnum = Number(evastart).toFixed(0)//该画几颗星
        for (var i = 0; i < starnum; i++) {
            $($('.alleavlinfor')[1]).append(' <i class="iconfont">&#xe9e6;</i>')
        }
        //几个评价
        var Lrecommended=(fivestart/Llen).toFixed(2)*100
        $($('.alleavlinfor')[2]).text('' + Llen + '个评价')
        $($('.alleavlinfor')[3]).text('' + Lrecommended+ '%')
    }
    ///涂颜色个评价条
    
   // console.log(newwidth)
   
    ///class="alleavlinfor"  Leverstart
    for(var i=0;i<5;i++){
        addnewwidth($($('.LstartStripcolor')[4-i]),Leverstart[i],Llen)//计算宽度
        $($('.Lstarnum')[i]).text('['+Leverstart[4-i]+']')
    }

}
function addnewwidth(obj,Larry,Llen){//计算宽度  "Lstarnum"
    var newwidth=(Larry/Llen).toFixed(2)*100*3
    obj.css('width',newwidth)
  
}