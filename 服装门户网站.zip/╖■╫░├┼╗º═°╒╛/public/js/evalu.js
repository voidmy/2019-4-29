$(function () {//用于评价
    //获取全部评价  showeaval
    var starnumarry=new Array()//得到所有星
    var search = location.search;         //获取URL中?后的句子
    var myparval = search.split("=")[1];
    var allevalu;
    $.ajax({
        type: 'post',
        url: '/goodsinfo/getevalgoods',
        data: {
            'evalId': '22',

        },
        dataType: 'json',
        success: function (result) {
            //onsole.log(result)
            allevalu = result


            for (i = 0; i < result.length; i++) {
                if (result[i].PicuUrl == myparval) {
                    evaladall($('#showeaval'), result[i])//得到所有评论
                }
            }


        }
    })
function repeval(author,Ttime,obj,catrepNum){//添加回复评论
 
    $.ajax({
        type: 'post',
        url: '/goodsinfo/getResponseevaluation',
        data: {
            'author':author ,
            'Ttime':Ttime,
            
        },
        dataType: 'json',
        success: function (result) {
            
            for(var i=0;i<result.length;i++){
                var myname=result[i].evalauthor;
                var text=result[i].evaltext
                var time=result[i].evaltime
                var $h4 = $('<div style="margin-left:30px; display:none;"></div>')
               
               
                $h4.append(' <h4><i>' + myname + '</i><i  style="opacity:0.5;">回复</i><i>' + author + '</i></h4>')
                $h4.append('<pre>' +text + '\n'+time+'</pre>')
                obj.append( $h4)
            }
            catrepNum.text('查看回复('+result.length+')')
           
        }
    })
  
  
}
////////////////////////
///查看回复按钮name="catrespong"
$('#showeaval').delegate('[name="catrespong"]','click',function(){
    var tarthis=$(this)
    var tartext=$(this).text()
    if(tarthis.attr('showorno')=='yes'){
        var text= tarthis.attr('renum')
        tarthis.text(text)
        tarthis.attr('showorno','no')
    }
    else{
        tarthis.attr('showorno','yes')
        tarthis.attr('renum',tartext)
        tarthis.text('收起回复')
    }
        $(this).parent().find('div').toggle(500,function(){
            
        })
     
        // $(this).
})

    //回复的事件委托
    $('#showeaval').delegate('[name="respong"]', 'click', function () {

        //console.log($(this).attr('name'))
        var restext = $(' <textarea  class="respeopletext"  id="huifueval" name="huifueval" cols="" rows=""></textarea>')
        var surebtn = $('<button  name="sureresbtn" class="btncalss" style="float:right;">确定回复</button>')
        var evapeople = $($(this).parent().find('h4')[0]).text()
        restext.attr('placeholder', '回复' + evapeople)
        $(this).parent().append(restext)//placeholder="请输入对商品评价"
        $(this).parent().append(surebtn)


    })
    ///回复pinglun按钮委托
    $('#showeaval').delegate('[ name="sureresbtn"]', 'click', function () {

        var evapeople = $($(this).parent().find('h4')[0]).text()
        //console.log(evapeople)
        var $h4 = $('<div style="margin-left:30px;"></div>')
        var $text = $('#huifueval').val()
        // console.log( $text)
        $h4.append(' <h4><i>' + $.cookie('name') + '</i><i  style="opacity:0.5;">回复</i><i>' + evapeople + '</i></h4>')
        $h4.append('<pre>' + $text + '</pre>')
 
        var evtime = $(this).parent().find('pre[name="evatime"]').text()//得到被评论的时间
        var newtime=evtime.split('\n')
        
        // $h4.append('')
        $(this).parent().append($h4)
        $("#huifueval").empty().remove()
        $(this).empty().remove()
        /**
         * evalId:String,//评论id
     PicuUrl:String,//图片地址
     beevalauthor:String,//被评论用户
     evalauthor:String,//评论人
     evaltext:String,//评论内容
      evaltime:String//评论时间
         */
        var myDate = new Date();
        //获取当前年
        var year = myDate.getFullYear();
        //获取当前月
        var month = myDate.getMonth() + 1;
        //获取当前日
        var date = myDate.getDate();
        var h = myDate.getHours();       //获取当前小时数(0-23)
        var m = myDate.getMinutes();     //获取当前分钟数(0-59)
        var s = myDate.getSeconds();
        var timeinfo2 = year + '/' + month + '/' + date + '/' + h + '/' + m + '/' + s
      //console.log(newtime[1])
    // console.log(newtime)
       $.ajax({
            type: 'post',
            url: '/goodsinfo/saveResponseevaluation',
            data: {
                'evalId':myparval ,//图片地址
                'beevaltime':newtime[1],
                'beevalauthor':evapeople,
                'evalauthor':$.cookie('name'),
                'evaltime':timeinfo2,
                'evaltext': $text
            },
            dataType: 'json',
            success: function (result) {
                //onsole.log(result)
                console.log("yes")

            }
        })
    })
    ///
    /** <div style="border-bottom: 1px solid gray;">
                                <h4>李重拳</h4>
                                <i class="iconfont">&#xe9e6;</i>
                                <i class="iconfont">&#xe9e6;</i>
                                <i class="iconfont">&#xe9e6;</i>
                                <i style="float:right;">回复</i>
                                <i style="float:right ;margin-right: 10px;">查看回复</i>
                                <pre>很好看 我喜欢</pre>
                            </div> */
    //$('#showeaval').append('')
    ///
    /*evalId:String,//评论id
    PicuUrl:String,//图片地址
    evalauthor:String,//评论人
    evaltext:String,//评论内容
     evaltime:String,//评论时间
   evalstarnum:String//评论星数*/
    ///
function evaladall(obj, arryeva) {//添加评论
        var conevadiv = $('<div style="border-bottom: 1px solid gray;"></div>')
        obj.append(conevadiv)
        conevadiv.append('<h4 name="evapeople">' + arryeva.evalauthor + '</h4>')
        for (var i = 0; i < arryeva.evalstarnum; i++) {
            conevadiv.append(' <i class="iconfont">&#xe9e6;</i>')
        }
        conevadiv.append('<i style="float:right;" name="respong">回复</i>')
        var catrepNum=$('<i style="float:right ;margin-right: 10px; " name="catrespong">查看回复</i>')
        conevadiv.append(catrepNum)
        conevadiv.append(' <pre name="evatime">' + arryeva.evaltext + '\n'+arryeva.evaltime+'</pre>')
        repeval(arryeva.evalauthor,arryeva.evaltime,conevadiv,catrepNum)//添加此评论的回复
        starnumarry.push(arryeva.evalstarnum)
       //var  len=starnumarry.length

 }
    ///



    $("#addeavl").click(function () {//点击平路判断
        if ($.cookie('name') != 'null' && $.cookie('name') != undefined) {
            $("#evalinptdiv").slideDown()
        }
        else {
            alert("请先登录")
        }
    })
    $("#evalinptdiv i").click(function () {//评价星数

        if ($(this).css('opacity') == 1) {
            $(this).css("opacity", "0.5")
        }
        else {
            $(this).css("opacity", "1")
        }

    })
    $("#sureaddeavl").click(function () {//确定评论
        $("#evalinptdiv").slideUp()
        //分割取出id
        var evatext = $("#evaluainputtext").val()
        var starnum = 0
        $("#evalinptdiv i").each(function () {
            if ($(this).css('opacity') == 1) {
                starnum++;
            }
        });
        var myDate = new Date();
        //获取当前年
        var year = myDate.getFullYear();
        //获取当前月
        var month = myDate.getMonth() + 1;
        //获取当前日
        var date = myDate.getDate();
        var h = myDate.getHours();       //获取当前小时数(0-23)
        var m = myDate.getMinutes();     //获取当前分钟数(0-59)
        var s = myDate.getSeconds();
        var timeinfo = year + '/' + month + '/' + date + '/' + h + '/' + m + '/' + s
        var evalkey = $.cookie('name') + '/' + timeinfo

        if (evatext != '') {//输入不为空时才能评论

            $.ajax({//
                type: 'post',
                url: '/goodsinfo/evalgoods',
                data: {
                    'evalId': evalkey,
                    'PicuUrl': myparval,
                    'evalauthor': $.cookie('name'),
                    'evaltext': evatext,
                    'evaltime': timeinfo,
                    'evalstarnum': starnum,
                },
                dataType: 'json',
                success: function (result) {
                    alert("评论成功")
                    window.location.reload();
                }

            })
        }
        /*
        evalId:String,//评论id
        PicuUrl:String,//图片地址
        evalauthor:String,//评论人
        evaltext:String,//评论内容
         evaltime:String,//评论时间
       evalstarnum:String//评论星数
       */

    })
})