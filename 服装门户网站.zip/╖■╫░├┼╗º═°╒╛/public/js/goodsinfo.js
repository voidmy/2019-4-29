
$(function () {

    var search = location.search;         //获取URL中?后的句子
    var myparval = search.split("=")[1];//获取id
    //showimgconsole.log(myparval)
    var text_value = myparval.replace("..", "");
    var src = '/public' + text_value
    console.log(src)
    // console.log()
    $("#showimg").attr('src', src)


}())
$("#addbtn").click(function () {
    var trlen = $("#sizetable tr").length
    
    if (trlen < 7) {
        var trdom = $('<tr><td> 尺码<input type="text"  class="inputsty" ></td><td> 数量<input  type="number"  ></td></tr>')
        $("#setmuen").before('<tr><td> 尺码<input type="text"  class="inputsty" ></td><td> 数量<input  type="number"  class="inputsty" ></td></tr>')
    }
    else {
        alert("最多允许添加六个")
    }
})
//
var setkey=new Array(6)
var  setval= new Array(6)//排序的数组
//点击确定
$("#surebtn").click(function(){
    setkey.splice(0, setkey.length)//清空数组
    setval.splice(0, setval.length)//清空数组
    var search = location.search;         //获取URL中?后的句子
    var myparval = search.split("=")[1];//获取id
    //console.log(myparval)
    var tartr = $("#sizetable tr [type='text']")
    var tarnumber = $("#sizetable tr [type='number']")
    for(var i=0;i<tartr.length;i++){
              setkey[i]=$(tartr[i]).val()
              setval[i]=$(tarnumber[i]).val()
         // console.log(key)
         // console.log(val)
    }
    /*
    onesize:String,
    onesizenumber:String,
    twosize:String,
    twosizenumber:String,
    threesize:String,
    threesizenumber:String,
    foursize:String,
    foursizenumber:String,
    fivesize:String,
    fivesizenumber:String,
    sixsize:String,
    sixsizenumber:String,
    */
    $.ajax({
        type: 'post',
        url: '/goodsinfo/setgoodssize',
        data: { 'PicuUrl': myparval,
                 'onesize':setkey[0],
                 'onesizenumber':setval[0],
                 'twosize':setkey[1],
                 'twosizenumber':setval[1],
                 'threesize':setkey[2],
                 'threesizenumber':setval[2],
                 'foursize':setkey[3],
                 'foursizenumber':setval[3],
                 'fivesize':setkey[4],
                 'fivesizenumber':setval[4],
                 'sixsize':setkey[5],
                 'sixsizenumber':setval[5]
               },
        dataType: 'json',
        success: function (result) {
              alert("添加成功")
        }

    })
 
})
/*$("#btn").click(function () {
    $.ajax({
        type: 'post',
        url: '/goodsinfo/setgoodssize',
        data: { 'name': "222" },
        dataType: 'json',
        success: function (result) {
               console.log(result.message)
        }

    })
    console.log(11)

})*/