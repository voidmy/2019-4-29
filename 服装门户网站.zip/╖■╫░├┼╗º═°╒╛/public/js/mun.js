var key = 1
var $switchPic = $("#switchpicu>img")
$switchPic.click(function () {
   var mypath = $(this).attr('src')
   testopen(mypath)
})

var mytimer
mytimer = setInterval(() => {
   // z-index: ;
   $($switchPic[key]).show()
   $($switchPic[key]).siblings().hide()//.css('z-index' ,'0')
   key++
   if (key == 3) { key = 0; }
   console.log(key)
}, 2000)
$("#switchpicu").mouseover(function () {
   clearInterval(mytimer)
}).mouseout(function () {
   mytimer = setInterval(() => {//轮播图
      // z-index: ;
      $($switchPic[key]).show()
      $($switchPic[key]).siblings().hide()//.css('z-index' ,'0')
      key++
      if (key == 3) { key = 0; }
      //console.log(key)
   }, 2000)
});
  $("#sheles").click(function(){//进入管理员level=3 界面
   var myval = window.open("http:/10.240.238.227:8080/public/html/administrator.html");
  })
function testopen(val) {
   var myval = window.open("http://10.240.238.227:8080/public/html/BrowseGoods.html?id=" + val + "");//?加图片路径
}
$("#selecbtn").click(function(){//点击搜索
    var seacgval=$("#selectext").val()
    var myval = window.open("http://10.240.238.227:8080/public/html/BrowseGoods.html?id=" + seacgval + "=2");//?加图片路径
})
$("#menuBrand table tr td img").click(function(){//点击品牌图片
   
 var seacgval=$(this).siblings().text()
var myval = window.open("http://10.240.238.227:8080/public/html/BrowseGoods.html?id=" + seacgval + "=2");//?加图片路径
})
$('#Lpersoninfo').click(function(){//点击个人信息界面
   if ($.cookie('code') == "null" || $.cookie('code') == undefined){
      alert('请先登陆')
   }else{
    window.open("http://10.240.238.227:8080/public/html/personinfo.html");
   }
})
/*$("#yundong").mouseover(function(){//品牌
   $("#menuBrand").stop()
 //  $("#menuBrand").slideDown();
    
})

$("#menuBrand").mouseout(function(){//品牌
   $("#menuBrand").stop()
   $("#menuBrand").slideUp();
})
$("#yundong").mouseout(function(){//品牌
   $("#menuBrand").stop()
   $("#menuBrand").slideUp();
})*/
$("#yundong").hover(function(){
   
   $("#menuBrand").stop()
   $("#menuBrand").slideDown();
},function(e){
   $("#menuBrand").stop()
  // $('#btn').trigger("click");  
   $("#menuBrand").slideUp(); 
 //  $("#menuBrand").hide();
})
$("#menuBrand").hover(function(){
   $("#menuBrand").stop()
   $("#menuBrand").slideDown();
},function(e){
   $("#menuBrand").stop()
   $("#menuBrand").slideUp(); 
 //  $("#menuBrand").hide();
})
