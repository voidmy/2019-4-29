
$(function () {
	///测试
	$($('.peopledata')[0]).hide()
	///
	if ($.cookie('name') == 'null' || $.cookie('name') == undefined) {
		$($('.Lmyname')[0]).html('请先登陆')
	}
	else {
		$('#Lheadoiv').attr('src', '../picture/earsh/head.jpg')
		$($('.Lmyname')[0]).html('亲爱的 <b>' + $.cookie("name") + '</b> 请完善您的个人信息，有助于我们更好服务哦。')
		///初始化界面
		$.ajax({
			type: 'post',
			url: '/people/people/get',
			data: {
				'usename': $.cookie('name')

			},
			dataType: 'json',
			success: function (result) {
				if (result.message) {
					//console.log(result)
				}
				else {
					//console.log(result)
					if (result.sex == '男') {
						$($("input[type='radio'][name='sex']")[0]).attr('checked', 'ture')
					}
					else if (result.sex == '女') {
						$($("input[type='radio'][name='sex']")[1]).attr('checked', 'ture')
					}
					$($('.Lmypereoinfo')[0]).val(result.nickname)
					$($('.Lmypereoinfo')[1]).val(result.truename)
					$($('input[type="date"]')[0]).val(result.birthday)
					var addre = result.Tolive.split('|')
					$($('.current')[0]).text(addre[0])
					$($('.current')[1]).text(addre[1])
					$($('.current')[2]).text(addre[2])
				}
			}
		})//
		////
		$('input[type="radio"][name="sex"]').click(function () {//得到性别
			// console.log( $("input[type='radio'][name='sex']:checked").val())
		})
		$('.current').click(function () {
			// console.log($(this).text())
		})

	}///

	$('#Lsaveperinfro').click(function () {//保存按钮
		var mync = $($('.Lmypereoinfo')[0]).val()
		var myname = $($('.Lmypereoinfo')[1]).val()
		var mysex = $("input[type='radio'][name='sex']:checked").val()//undefined
		var mydate = $($('input[type="date"]')[0]).val()
		var myaddressthree = $($('.current')[2]).text()

		var myaddress = $($('.current')[0]).text() + '|' + $($('.current')[1]).text() + '|' + $($('.current')[2]).text()

		/*
		 usename:String, 
   nickname:String,
   truename:String,
   sex:String,
   birthday:String,
   Tolive:String
		*/
		if ($.cookie('name') == 'null' || $.cookie('name') == undefined) {
			alert('请先登陆')
		}
		else {
			$.ajax({
				type: 'post',
				url: '/people/people/save',
				data: {
					'usename': $.cookie('name'),
					'nickname': mync,
					'truename': myname,
					'sex': mysex,
					'birthday': mydate,
					'Tolive': myaddress
				},
				dataType: 'json',
				success: function (result) {
					//console.log(yes);
				}
			})//
		}

	})
	//
	$('.headtextchose').click(function (e) {
		//console.log($(this).index());
		$(this).css('opacity', '1')
		$(this).siblings().css('opacity', '0.5')
		$($('.peopledata')[$(this).index()]).show()
		$($('.peopledata')[$(this).index()]).siblings().hide()
	})

	$(".files1").on("change", function (e) {//选择图片
		var e = e || window.event;
		var files = e.target.files;
		var file = files[0];
		//////显示图片
		var myurl = URL.createObjectURL(file)
		$("#showimg").attr('src', myurl)
		
		$($('.headbtn')[0]).click(function(){
			var formData = new FormData();
			formData.append('files1', file);
			formData.append('usename', $.cookie('name'));
			///
			$.ajax({
				url: '/people/people/saveheadpic',
				type: "post",
				data: formData,
				contentType: false,//使用multer配合ajax时无需配置multipart/form-data，multer将自动配置，手动配置将报错，boundary not found
				processData: false,
				success: function (sult) {
					console.log(sult.msg)
					alert('上传头像成功')
				},
				error: function (err) {
					console.log(err);
				}
			});
		})
		///
	})
	////处理省市区联动
	var json_text = arrCity;
	(function () {// ////处理省市区联动
		var Pro = function (p) {
			for (var i = 0; i < p.length; i++) {
				//打印各个省份对应列表
				var option = "<span value='" + p[i].name + "'data-i='" + i + "'>" + p[i].name + "</span>";
				$(".selProvince .box").append(option);
				$(".selProvince .box span:eq(0)").hide();
			}
			$(".selCity .current").change(function () {
				var ProId = $(".selProvince .box").attr("data-i");
				var CityId = $(".selCity .box").attr("data-j");
				var selCityValue = $(this).val();
				//让区域选项值为默认值
				$(".selArea .box").remove();
				if (p[ProId].type == "1") {
					for (var k = 0; k < p[ProId].sub[CityId].sub.length; k++) {
						var option = "<span value='" + p[ProId].sub[CityId].sub[k].name + "'data-k='" + k + "'>" + p[ProId].sub[CityId].sub[k].name + "</span>";
						$(".selArea").append(option);
						$(".selArea .box span:eq(0)").hide();
					}
				}
			});
		};
		Pro(json_text);
		$(".selProvince").find(".current").click(function () {
			$(".selProvince").find(".box").toggle(0); $(".selCity").find(".box").hide(); $(".selArea").find(".box").hide();
		});
		$(".selCity").find(".current").click(function () {
			$(".selCity").find(".box").toggle(0); $(".selProvince").find(".box").hide(); $(".selArea").find(".box").hide();
		});
		$(".selArea").find(".current").click(function () {
			$(".selArea").find(".box").toggle(0); $(".selProvince").find(".box").hide(); $(".selCity").find(".box").hide();
		});
		$(".selProvince .box span").each(function () {
			$(this).click(function () {
				var p = json_text;
				var ProId = $(this).attr("data-i");
				//让城市选项值为默认值
				$(".selCity .box span").remove();
				$(".selCity .current").html("--请选择--");
				//让区域选项值为默认值
				$(".selArea .box span").remove();
				$(".selArea .current").html("--请选择--");
				$(".selProvince").find(".box").hide();
				$(".selProvince").find(".current").html($(this).html());

				var selValue = $(this).html();
				for (var i = 0; i < p.length; i++) {
					if (selValue == p[i].name) {
						for (var j = 0; j < p[i].sub.length; j++) {
							//打印各个省份对应城市列表
							var option = "<span value='" + p[i].sub[j].name + "'data-j='" + j + "'>" + p[i].sub[j].name + "</span>";
							$(".selCity .box").append(option);
							$(".selCity .box span:eq(0)").hide();
						}
					}
				}
				$(".selCity .box span").each(function () {
					$(this).click(function () {
						//让区域选项值为默认值
						$(".selArea .box span").remove();
						$(".selArea .current").html("--请选择--");
						var p = json_text;
						$(".selCity").find(".box").hide();
						$(".selCity").find(".current").html($(this).html());
						var CityId = $(this).attr("data-j");
						var selCityValue = $(this).html();
						//让区域选项值为默认值
						if (p[ProId].type == "1") {
							for (var k = 0; k < p[ProId].sub[CityId].sub.length; k++) {
								var option = "<span value='" + p[ProId].sub[CityId].sub[k].name + "'data-k='" + k + "'>" + p[ProId].sub[CityId].sub[k].name + "</span>";
								$(".selArea .box").append(option);
								$(".selArea .box span:eq(0)").hide();
							}
						}
						$(".selArea .box span").click(function () {
							$(".selArea .box").hide();
							$(".selArea .current").html($(this).html());
						});
					})
				});
			});
		});
	})()
	/////
})
