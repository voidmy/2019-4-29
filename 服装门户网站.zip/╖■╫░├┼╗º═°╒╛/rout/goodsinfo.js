var express = require('express');
var router = express.Router();
var fs = require("fs");
var html = fs.readFileSync("goodsinfo.html");
var Goodsinfo = require('../models/Goodsinfo');//商品信息表
var GoodsSize = require('../models/goodssize');
var  myevalution= require('../models/evaluation');//评论表
var Responseevaluation=require("../models/Responseevaluation")
var responData;
router.use(function (req, res, next) {
    responData = {
        code: 0,
        message: ''
    }
    next();
});
router.get('/send', function (req, res, next) {
    // console.log(req.headers.cookie)
    var cookie = req.headers.cookie
    var mycook = cookie.toString().split(";")[1].split("=")[1]//得到登录的等级
    if (mycook == 3) {
        res.write(html);
    } else {
        res.send("非管理员禁止进入后台！")
    }

})
router.post('/setgoodsinfo', function (req, res, next) {
    // console.log(req.headers.cookie)
    var name = req.body.name
    var goods = new Goodsinfo({
        GoodsId: name,
        PicuUrl: name,
        views: name,
        evaluaNumber: name,
        sales: name,
        shelftime: name
    })
    //goods.save()

    console.log(req.body.name)
    responData.code = 10;
    responData.message = "222"
    // responData.isAdmin=userinfo.isAdmin;
    // console.log(userinfo.isAdmin);
    res.json(responData);
})
router.post('/setgoodssize', function (req, res, next) {
    // console.log(req.headers.cookie)
    
    var goodssize = new GoodsSize({
        GoodsId:'',
        PicuUrl: req.body.PicuUrl,
        onesize: req.body.onesize,
        onesizenumber: req.body.onesizenumber,
        twosize:  req.body.twosize,
        twosizenumber: req.body.twosizenumber,
        threesize: req.body.threesize,
        threesizenumber:  req.body.threesizenumber,
        foursize: req.body.foursize,
        foursizenumber:  req.body.foursizenumber,
        fivesize:  req.body.fivesize,
        fivesizenumber:  req.body.fivesizenumber,
        sixsize: req.body.sixsize,
        sixsizenumber: req.body.sixsizenumber,
    })
    goodssize.save()

    //console.log(req.body.name)
    responData.code = 10;
    responData.message = "222"
    // responData.isAdmin=userinfo.isAdmin;
    // console.log(userinfo.isAdmin);
    res.json(responData);
})
router.post('/getgoodssize', function (req, res, next) {
   var PicuUrl=req.body.PicuUrl
   GoodsSize.findOne({
    PicuUrl:PicuUrl
   }).then(function(inforsiez){
    res.json(inforsiez)
    //console.log(inforsiez)
   })
    
   
})
///评论 myevalution
router.post('/evalgoods',function(req,res,next){

     /*
         evalId:String,//评论id
         PicuUrl:String,//图片地址
         evalauthor:String,//评论人
         evaltext:String,//评论内容
          evaltime:String,//评论时间
        evalstarnum:String//评论星数
        */
    var neweval=new myevalution({
        evalId:req.body.evalId,
        PicuUrl:req.body.PicuUrl,
        evalauthor:req.body.evalauthor,
        evaltext:req.body.evaltext,
        evaltime:req.body.evaltime,
        evalstarnum:req.body.evalstarnum,

    })
    neweval.save()
    //console.log(req.body)
    responData.code = 12;
    responData.message = "评论成功"
    res.json(responData);

})
router.post('/getevalgoods',function(req,res,next){//得到所有评论

    myevalution.find().then(function(evalu){
        res.json(evalu);
    })
   //console.log(req.body)
  

})
router.post('/saveResponseevaluation',function(req,res,next){
   var reev=new Responseevaluation({
    PicuUrl:req.body.PicuUrl,//图片地址
    beevalauthor:req.body.beevalauthor,//被评论用户
    beevaltime:req.body.beevaltime,//被评论时间
    evalauthor:req.body.evalauthor,//评论人
    evaltext:req.body.evaltext,//评论内容
     evaltime:req.body.evaltime//评论时间
    })
    reev.save()
  // console.log(req.body)
   responData.code = 12;
   responData.message = "评论成功"
   res.json(responData);

})
router.post('/getResponseevaluation',function(req,res,next){//得到回复的评论
    
    var beevalauthor=req.body.author;
    var beevaltime=req.body.Ttime
     Responseevaluation.find({
        beevalauthor:beevalauthor,
        beevaltime:beevaltime
     }).then(function(infor){
        // console.log(infor)
         res.json(infor)
     })
    
 
 })
module.exports = router;