var express = require('express');
var router = express.Router();
//
//

var multer = require('multer');
/**
 * process.cwd()获取项目根目录地址，可以将上传的文件指定到静态文件目录下，然后再返回地址给前端页面，如：
 * var uploadPath = process.cwd()+'/public/uploads' 前端访问地址 http://localhost:3000/uploads/文件名
 **/
var uploadPath = process.cwd() + '/public/picture/earsh';//直接存放在根目录下uploads
var storage = multer.diskStorage({//multer存储引擎  存储引擎自定义引用 https://github.com/expressjs/multer/blob/master/StorageEngine.md
    destination: uploadPath,//指定上传文件的路径
    filename: function (req, file, cb) { cb(null, file.fieldname + '-' + Date.now()) }
}) //命名上传文件
var multer = multer({
    storage: storage
    //limits：''//Limits of the uploaded data
}).single('files1');//single 单文件上传，files1为form表单中 接受文件的name字段名称
///
var peopleinfo = require('../models/people');//

var responData;
router.use(function (req, res, next) {
    responData = {
        code: 0,
        message: ''
    }
    next();
});
router.post('/people/save', function (req, res, next) {

    var usename = req.body.usename
    var nickname = req.body.nickname
    var truename = req.body.truename
    var sex = req.body.sex
    var birthday = req.body.birthday
    var Tolive = req.body.Tolive

    peopleinfo.findOne({
        usename: usename
    }).then(function (infor) {
        if (infor) {
            console.log(infor)
            peopleinfo.updateOne({ usename: usename }, {
                usename: usename,
                nickname: nickname,
                truename: truename,
                sex: sex,
                birthday: birthday,
                Tolive: Tolive

            }, function (err, res) {
                if (err) {
                    console.error("Error: " + err);
                } else {
                    console.log("Res: " + res);
                }
            })
            return;
        }
        else {
            var people = new peopleinfo({
                usename: usename,
                nickname: nickname,
                truename: truename,
                sex: sex,
                birthday: birthday,
                Tolive: Tolive

            })
            people.save()
            return;
        }
    })

})
router.post('/people/get', function (req, res, next) {
    var usename = req.body.usename
    peopleinfo.findOne({
        usename: usename
    }).then(function (info) {
        if (info) {
            res.json(info)
        } else {
            responData.code = 4
            responData.message = "未设置个人信息"
            res.json(responData)
        }
    })
})
router.post('/people/saveheadpic', function (req, res, next) {

    multer(req, res, function (err) {
        if (err) {
            console.log(err);
            return;
        }
        var usename = req.body.usename
        peopleinfo.findOne({
            usename: usename
        }).then(function (info) {
            if (info) {
                console.log(usename)
                console.log(req.file.path)
                peopleinfo.updateOne({ usename: usename }, { heardpic: req.file.path }, function (err, res) {
                    if (err) {
                        console.error("Error: " + err);
                    } else {
                        console.log("Res: " + res);
                    }
                }
                )
            }
            else{
                var newpeoplepic=new peopleinfo({
                    usename: usename,
                    heardpic: req.file.path
                })
                newpeoplepic.save()
            }

        })
        console.log(req.file.filename)
        res.send({ msg: '上传成功', img: req.file.path });
    })
})
module.exports = router;