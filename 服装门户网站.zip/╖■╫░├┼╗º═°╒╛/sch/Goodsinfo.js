var mongoose=require('mongoose');
 module.exports=new mongoose.Schema({
    ///
    GoodsId:String,
    PicuUrl:String,
    views:String,
    evaluaNumber:String,
    sales:String,
    shelftime:String
});