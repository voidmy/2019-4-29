var mongoose=require('mongoose');
 module.exports=new mongoose.Schema({
    ///
    evalId:String,//评论id
    PicuUrl:String,//图片地址
    beevalauthor:String,//被评论用户
    beevaltime:String,//被评论时间
    evalauthor:String,//评论人
    evaltext:String,//评论内容
     evaltime:String//评论时间
  
});