var mongoose=require('mongoose');
 module.exports=new mongoose.Schema({
    ///
    evalId:String,//评论id
    PicuUrl:String,//图片地址
    evalauthor:String,//评论人
    evaltext:String,//评论内容
     evaltime:String,//评论时间
   evalstarnum:String//评论星数
});