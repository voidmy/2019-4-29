var mongoose=require('mongoose');
 module.exports=new mongoose.Schema({
    ///
    GoodsId:String,
    PicuUrl:String,
    onesize:String,
    onesizenumber:String,
    twosize:String,
    twosizenumber:String,
    threesize:String,
    threesizenumber:String,
    foursize:String,
    foursizenumber:String,
    fivesize:String,
    fivesizenumber:String,
    sixsize:String,
    sixsizenumber:String,
});