var mongoose=require('mongoose');
 module.exports=new mongoose.Schema({
    ///
   usename:String, 
   nickname:String,
   truename:String,
   sex:String,
   birthday:String,
   Tolive:String,
   heardpic:String     
});